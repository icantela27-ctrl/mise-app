# Mise deployment package

This package contains a static HTML prototype ready for fast deployment.

## Netlify Drop
1. Open https://app.netlify.com/drop
2. Drag `mise-app.html` into the page
3. Netlify will publish it and return a public URL

## Vercel
1. Upload this package to a GitHub repository
2. Import the repository into Vercel
3. Use the `Other` preset
4. No build command is required for this static app

## Important note
This is a deployable front-end prototype. It does not yet include a backend, shared database, authentication, or persistent storage.
